package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_Page2 {

	WebDriver dr1;
	By uname =By.id("user-name");
	By pwd=By.id("password");
	By log_btn=By.xpath("/html/body/div[2]/div[1]/div[1]/div/form/input[3]");
	public Login_Page2 (WebDriver dr) {
		this.dr1=dr;
	}
	public void enter_username(String username) {
		dr1.findElement(uname).sendKeys(username);
		}
	

   public void enter_password(String password) {
	dr1.findElement(pwd).sendKeys(password);
	}
		
	
		public void click_login_btn() {
			dr1.findElement(log_btn).click();
	}
public void do_login(String username,String password) {
	this.enter_username(username);
	this.enter_password(password);
	this.click_login_btn();
}
}
