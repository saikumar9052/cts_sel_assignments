package TESTS;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;


import PAGES.Login_Page2;

public class NewTest1 {
	WebDriver dr;
	
	Login_Page2 lp;
	
  
  @BeforeClass
  public void launchbrowser() {
	  System.setProperty("webdriver.chrome.driver", "G://chromedriver_win32//chromedriver.exe/");
	  dr =new ChromeDriver();
	  dr.get("http://www.saucedemo.com/");
	  
	  lp=new Login_Page2(dr); 
  }
  @Test
  public void logintest1() {
 lp.do_login("standard_user", "secret_sauce");
  }

  @AfterClass
 public void closebrowser() {
	  dr.close();
  }}


