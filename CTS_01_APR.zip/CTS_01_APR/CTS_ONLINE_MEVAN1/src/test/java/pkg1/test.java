package pkg1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class test {
  @Test
  public void f() {
	  System.out.println("In maven testing");
	  System.setProperty("webdriver.chrome.driver", "G:/chromedriver_win32/chromedriver.exe");
	   WebDriver dr =new ChromeDriver();
	  dr.get("http://www.demowebshop.com/");
	  
  }
}
