package mypkg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelRW {
	
	private static Workbook wb;
	private static org.apache.poi.ss.usermodel.Sheet sh;
	private static FileInputStream fis;
	private static FileOutputStream fos;
	private static Row row;
	private static Cell cell;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		fis = new FileInputStream("/G://New folder (5)//textdata.xlsheet.xlsx/");
		wb=WorkbookFactory.create(fis);
		sh=wb.getSheet("Sheet1");
		int noOfRows = sh.getLastRowNum();
		System.out.println(noOfRows);
		
		row = sh.createRow(1);
		cell = row.createCell(0);
		cell.setCellValue("SAI");
		System.out.println(cell.getStringCellValue());
		fos = new FileOutputStream("/G://New folder (5)//textdata.xlsheet.xlsx/");
		wb.write(fos);
		fos.flush();
		fos.close();
		System.out.println("DONE");
		
		

	}

}
