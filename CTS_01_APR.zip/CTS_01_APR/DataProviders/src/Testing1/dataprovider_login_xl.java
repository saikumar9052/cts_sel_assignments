package Testing1;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
public class dataprovider_login_xl extends dataprovider_login {


basic_testlogin test;
@BeforeClass
public void get_data() {

get_test_data();
}

 @Test(dataProvider = "login_data")
 public void logintest(String eid, String pwd, String exp_eid) {
test = new basic_testlogin();
String a_eid = test.login(eid, pwd);
SoftAssert sa = new SoftAssert();
sa.assertEquals(a_eid, exp_eid);
sa.assertAll();
// System.out.println("email id : " + eid + " pwd : " + pwd + " expected res : " + exp_eid);
 }
 
 @DataProvider(name="login_data")
 public String[][] provide_data()
 {
    return testdata;
 }

}


