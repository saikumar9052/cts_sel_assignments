package Testing1;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.DataProvider;

public class DataProviderBasic {
	basic_testlogin test;
	
  @Test(dataProvider = "login_data")
  public void logintest(String eid, String pwd,String exp_eid) {
	 // System.out.println("email id:"+eid + "pwd:"+pwd);
  
  test = new basic_testlogin();
  String a_eid = test.login(eid,pwd);
  SoftAssert sa = new SoftAssert();
  sa.assertEquals(a_eid,exp_eid);
  sa.assertAll();
  }

  @DataProvider(name="login_data")
  public String[][] provide_data()
  {
    String[][] data= {
       { "saikunchala.kumar@gmail.com", "123123123" , "saikunchala.kumar@gmail.com"},
       { "saikunchala.kumar@gmail.com", "123123123", "saikumar9052@gmail.com"},
       
    };
    return data;
  }
}
