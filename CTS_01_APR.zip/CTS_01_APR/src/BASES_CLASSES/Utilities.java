package BASES_CLASSES;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Utilities {
WebDriver  dr;
public static WebDriver launch_browser(String browser, String url) {
WebDriver dr = null;
String ch_driver_path="chromedriver.exe";
String ff_driver_path="geckodriver.exe";
switch(browser) {
case "chrome":
System.setProperty("webdriver.chrome.driver", ch_driver_path);
dr = new ChromeDriver();
break;
case "firefox":
System.setProperty("webdriver.gecko.driver", ff_driver_path);
dr = new FirefoxDriver();
break;
default:
System.out.println("Supported browser optios:chrome & firefox");
break;
}
dr.get(url);
dr.manage().window().maximize();
dr.manage().timeouts().implicitlyWait(20,  TimeUnit.SECONDS);
return dr;

}


}



