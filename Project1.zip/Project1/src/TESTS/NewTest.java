package TESTS;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import PAGES.Home_Page;
import PAGES.Login_Page;

public class NewTest {
WebDriver dr;
Home_Page hp;
Login_Page lp; 
  
  @BeforeClass
  public void launchbrowser() {
	  System.setProperty("webdriver.chrome.driver", "G://chromedriver_win32//chromedriver.exe/");
	  dr =new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/");
	  hp=new Home_Page(dr);
	  lp=new Login_Page(dr);
	  }
  @Test
  public void logintest1() {
 hp.click_login_link();
 lp.do_login("saikumar9052@gmail.com", "123123123");
  }
  
  

  @AfterClass
  public void closebrowser() {
	  dr.close();
  }

}
